# coding=utf-8
from data_factory import DataManager
import numpy as np
from sklearn.svm import SVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score

np.random.seed(1374)

X = np.loadtxt('X_train.txt', dtype=int)
Y_ori = np.loadtxt('Y_train.txt', dtype=int)

Y = []
for i in range(len(Y_ori)):
    Y.append(np.argmax(Y_ori[i]))

Y = np.asarray(Y)

idx = range(len(Y))
np.random.shuffle(idx)
X = [X[i] for i in idx]
Y = [Y[i] for i in idx]
X = np.asarray(X)
Y = np.asarray(Y)

split = int(0.2 * len(Y))

X_test = X[:split]
Y_test = Y[:split]

X_train = X[split:]
Y_train = Y[split:]


clf = OneVsRestClassifier(LinearSVC(random_state=0, loss='hinge')).fit(X_train, Y_train)
print '\ntrain acc:', accuracy_score(clf.predict(X_train), Y_train)
#print '\ntrain acc:',np.sum(np.asarray(clf.predict(X_train) == Y_train))/ (1.0 * len(Y_train))

print '\ntest acc:', accuracy_score(clf.predict(X_test), Y_test)
#print '\ntrain acc:',np.sum(np.asarray(clf.predict(X_test) == Y_test))/ (1.0 * len(Y_test))








