from data_factory import DataManager
import numpy as np
from sklearn.svm import SVC
trainParh = '../data/train.json'
testPath = '../data/test.json'
savePath = '../data/predictions_svm.txt'
dm = DataManager()

train_data, test_data = dm.load_data(trainParh,testPath)
train_data, train_label, test_data, vocab, labels = dm.process_data(train_data,test_data)

labels = list(labels)

#train_label = [np.where(label==1)[0] for label in train_label]

# np.savetxt('X_train.txt', train_data, fmt='%d')
# np.savetxt('X_test.txt', test_data, fmt='%d')
# np.savetxt('Y_train.txt', train_label, fmt='%d')
# np.savetxt('labels.txt', labels, fmt='%s')

print labels

# b = np.loadtxt('X_train.txt', dtype=int)
# print b
# In [4]: a == b
# Out[4]: array([ True,  True,  True,  True], dtype=bool)